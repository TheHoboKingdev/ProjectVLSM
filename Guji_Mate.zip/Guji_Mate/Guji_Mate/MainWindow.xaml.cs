﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Guji_Mate
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AlhaloG.Visibility = Visibility.Hidden;
            Vlsm.Visibility = Visibility.Hidden;
        }
        private void sugoGomb_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Gépelje be a hálózati cím négy oktettjét a megfelelő rublikákba. Szóközt és pontot ne használjon! Az ötödik rublikába írja bele " +
                "az alhálózati maszkot decimális alakban! Szóközt és perjelet ne használjon! \n Az \"Alhálózatokra bontás\" rádiógombra való kattintás után adja meg, hogy " +
                "hány egyenlő részre szeretné bontani a címet. A \"Számít\" gombra való kattintás után a program elvégzi a számítást a megadott feltételeknek megfelelően \n  " +
                "A \"VLSM\" rádiógombra való kattintás után adja meg, melyik hálózatban mennyi hosztot szeretne. Elsőként a legtöbb hosztot igénylő hálózat méretét írja be a beviteli mezőbe, másodjára a második legtöbb hosztot igénylő hálózatét és így tovább." +
                " Amennyiben elírt valamit,vagy szerkeszteni szeretné valamelyik hálózat méretét, a mellete elhelyezett jelőlőnégyzet bepipálásával átírhatja a beviteli mezőben megadot értéket és a \"Módosít\" gombra kattintva már módosításra is kerül az érték. A \"Számít\" gombra való kattintás után a program elvégzi a számítást a megadott feltételeknek megfelelően");
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            AlhaloG.Visibility = Visibility.Visible;
            Vlsm.Visibility = Visibility.Hidden;
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            AlhaloG.Visibility = Visibility.Hidden;
            Vlsm.Visibility = Visibility.Visible;
        }
    }
}
