﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Guji_Mate
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<VLSM> hostok = new List<VLSM>();
        public MainWindow()
        {
            InitializeComponent();
            AlhaloG.Visibility = Visibility.Hidden;
            Vlsm.Visibility = Visibility.Hidden;
        }
        private void sugoGomb_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Gépelje be a hálózati cím négy oktettjét a megfelelő rublikákba. Szóközt és pontot ne használjon! Az ötödik rublikába írja bele " +
                "az alhálózati maszkot decimális alakban! Szóközt és perjelet ne használjon! \n\n Az \"Alhálózatokra bontás\" rádiógombra való kattintás után adja meg, hogy " +
                "hány egyenlő részre szeretné bontani a címet. A \"Számít\" gombra való kattintás után a program elvégzi a számítást a megadott feltételeknek megfelelően \n\n  " +
                "A \"VLSM\" rádiógombra való kattintás után adja meg, melyik hálózatban mennyi hosztot szeretne. Elsőként a legtöbb hosztot igénylő hálózat méretét írja be a beviteli mezőbe, másodjára a második legtöbb hosztot igénylő hálózatét és így tovább.\n\n" +
                " Amennyiben elírt valamit, vagy szerkeszteni szeretné valamelyik hálózat méretét, a mellete elhelyezett jelőlőnégyzet bepipálásával átírhatja a beviteli mezőben megadot értéket és a \"Módosít\" gombra kattintva már módosításra is kerül az érték.\n\n A \"Számít\" gombra való kattintás után a program elvégzi a számítást a megadott feltételeknek megfelelően");
        }
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            AlhaloG.Visibility = Visibility.Visible;
            Vlsm.Visibility = Visibility.Hidden;
        }
        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            AlhaloG.Visibility = Visibility.Hidden;
            Vlsm.Visibility = Visibility.Visible;
        }
        class IP
        {
            public double ElsoOktett;
            public double MasodikOktett;
            public double HarmadikOktett;
            public double NegyedikOktett;
            public double Maszk;
            public IP(string ElsoOktett, string MasodikOktett, string HarmadikOktett, string NegyedikOktett, string Maszk)
            {
                this.ElsoOktett = double.Parse(ElsoOktett);
                this.MasodikOktett = double.Parse(MasodikOktett);
                this.HarmadikOktett = double.Parse(HarmadikOktett);
                this.NegyedikOktett = double.Parse(NegyedikOktett);
                this.Maszk = double.Parse(Maszk);
            }
            public string Kiiratas { get => $"{ElsoOktett}.{MasodikOktett}.{HarmadikOktett}.{NegyedikOktett}"; }
        }
        private string Decimalis(int maszk)
        {
            string decimalisMaszk;
            int[] oktettMaszk = { 0, 0, 0, 0 };
            int maradekMaszk = maszk - maszk % 8;
            if (maszk < 8)
                oktettMaszk[0] = Vizsgalat(maszk);
            else if (maszk == 8)
                oktettMaszk[0] = 255;
            else if (maszk < 16 && maszk > 8)
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = Vizsgalat(maszk % 8);
            }
            else if (maszk == 16)
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = 255;
            }
            else if (maszk < 24 && maszk > 16)
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = 255;
                oktettMaszk[2] = Vizsgalat(maszk % 8);
            }
            else if (maszk == 24)
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = 255;
                oktettMaszk[2] = 255;
            }
            else
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = 255;
                oktettMaszk[2] = 255;
                oktettMaszk[3] = Vizsgalat(maszk % 8);
            }
            decimalisMaszk = $"{oktettMaszk[0]}.{oktettMaszk[1]}.{oktettMaszk[2]}.{oktettMaszk[3]}";
            return decimalisMaszk;
        }
        private int Vizsgalat(int vizsgalando)
        {
            switch (vizsgalando)
            {
                case 1:
                    return 128;
                    break;
                case 2:
                    return 192;
                    break;
                case 3:
                    return 224;
                    break;
                case 4:
                    return 240;
                    break;
                case 5:
                    return 248;
                    break;
                case 6:
                    return 252;
                    break;
                default:
                    return 254;
                    break;
            }
        }
        private void szamitBal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IP generalasIP = new IP(elsoOktett.Text, masodikOktett.Text, harmadikOktett.Text, negyedikOktett.Text, maszk.Text);
                int hatvany = 1;
                int seged = 2;
                if (generalasIP.Maszk <= 0 || generalasIP.Maszk >= 31)
                {
                    MessageBox.Show("Hibás hálózati maszk!");
                    maszk.Text = "";
                }
                else
                {
                    for (int i = hostok.Count-1; i > 1; i--)
                    {
                        for (int j = 0; j < i; j++)
                        {
                            if (hostok[j].hostSzam < hostok[j+1].hostSzam)
                            {
                                VLSM seged2 = hostok[j];
                                hostok[j] = hostok[j + 1];
                                hostok[j + 1] = seged2;
                            }
                        }
                    }
                    while (Math.Pow(seged, hatvany) <= int.Parse(beviteliMezoBal.Text))
                    {
                        hatvany++;
                    }
                    if (hatvany >= 8)
                    {
                        MessageBox.Show("Túl sok részre akarja bontani a hálózatot!");
                    }
                    else
                    {
                        int keszMaszk = (int)generalasIP.Maszk + hatvany;
                        string kiirasok = $"Host neve\t\tHálózati cím\t\tKiosztható címek\t\tSzórási cím\tHálózati maszk\tHálózati maszk decimális formában\n";
                        string[] halozatiCim = generalasIP.Kiiratas.Split('.');
                        for (int i = 0; i < int.Parse(beviteliMezoBal.Text); i++)
                        {
                            if (keszMaszk < 8 && keszMaszk > 0)
                            {
                                //hálózati
                                kiirasok += $"Host{i + 1}\t\t{generalasIP.Kiiratas}\t";
                                //kiosztható
                                generalasIP.ElsoOktett = int.Parse(halozatiCim[0]) + 1;
                                kiirasok += $"{generalasIP.Kiiratas}\t";
                                generalasIP.ElsoOktett = int.Parse(halozatiCim[0]);
                                generalasIP.ElsoOktett = int.Parse(halozatiCim[0]) + Math.Pow(seged, hatvany) - 2;
                                kiirasok += $"{generalasIP.Kiiratas}\t";
                                generalasIP.ElsoOktett = int.Parse(halozatiCim[0]);
                                //szórási
                                generalasIP.ElsoOktett = int.Parse(halozatiCim[0]) + Math.Pow(seged, hatvany) - 1;
                                if (int.Parse(halozatiCim[0]) >= 256)
                                {
                                    int maradek = int.Parse(halozatiCim[0]) - 255;
                                    halozatiCim[1] = maradek.ToString();
                                }
                                //maszkok
                                kiirasok += $"{generalasIP.Kiiratas}\t/{keszMaszk}\t\t{Decimalis(keszMaszk)}\n";
                                generalasIP.ElsoOktett = int.Parse(halozatiCim[0]) + Math.Pow(seged, hatvany);
                                halozatiCim[0] = generalasIP.ElsoOktett.ToString();
                            }
                            else if (keszMaszk >= 8 && keszMaszk < 16)
                            {
                                //hálózati
                                kiirasok += $"Host{i + 1}\t\t{generalasIP.Kiiratas}\t";
                                //kiosztható
                                generalasIP.MasodikOktett = int.Parse(halozatiCim[1]) + 1;
                                kiirasok += $"{generalasIP.Kiiratas}\t";
                                generalasIP.MasodikOktett = int.Parse(halozatiCim[1]);
                                generalasIP.MasodikOktett = int.Parse(halozatiCim[1]) + Math.Pow(seged, hatvany) - 2;
                                kiirasok += $"{generalasIP.Kiiratas}\t";
                                generalasIP.MasodikOktett = int.Parse(halozatiCim[1]);
                                //szórási
                                generalasIP.MasodikOktett = int.Parse(halozatiCim[1]) + Math.Pow(seged, hatvany) - 1;
                                if (int.Parse(halozatiCim[1]) >= 256)
                                {
                                    int maradek = int.Parse(halozatiCim[1]) - 255;
                                    halozatiCim[2] = maradek.ToString();
                                }
                                //maszkok
                                kiirasok += $"{generalasIP.Kiiratas}\t/{keszMaszk}\t\t{Decimalis(keszMaszk)}\n";
                                generalasIP.MasodikOktett = int.Parse(halozatiCim[1]) + Math.Pow(seged, hatvany);
                                halozatiCim[1] = generalasIP.MasodikOktett.ToString();
                            }
                            else if (keszMaszk >= 16 && keszMaszk < 24)
                            {
                                //hálózati
                                kiirasok += $"Host{i + 1}\t\t{generalasIP.Kiiratas}\t";
                                //kiosztható
                                generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]) + 1;
                                kiirasok += $"{generalasIP.Kiiratas}\t";
                                generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]);
                                generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]) + Math.Pow(seged, hatvany) - 2;
                                kiirasok += $"{generalasIP.Kiiratas}\t";
                                generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]);
                                //szórási
                                generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]) + Math.Pow(seged, hatvany) - 1;
                                if (int.Parse(halozatiCim[2]) >= 256)
                                {
                                    int maradek = int.Parse(halozatiCim[2]) - 255;
                                    halozatiCim[3] = maradek.ToString();
                                }
                                //maszkok
                                kiirasok += $"{generalasIP.Kiiratas}\t/{keszMaszk}\t\t{Decimalis(keszMaszk)}\n";
                                generalasIP.HarmadikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany);
                                halozatiCim[3] = generalasIP.HarmadikOktett.ToString();
                            }
                            else if (keszMaszk >= 24 && keszMaszk < 32)
                            {
                                //hálózati
                                kiirasok += $"Host{i + 1}\t\t{generalasIP.Kiiratas}\t";
                                //kiosztható
                                generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + 1;
                                kiirasok += $"{generalasIP.Kiiratas}\t";
                                generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]);
                                generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany) - 2;
                                kiirasok += $"{generalasIP.Kiiratas}\t";
                                generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]);
                                //szórási
                                generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany) - 1;
                                //maszkok
                                kiirasok += $"{generalasIP.Kiiratas}\t/{keszMaszk}\t\t{Decimalis(keszMaszk)}\n";
                                generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany);
                                halozatiCim[3] = generalasIP.NegyedikOktett.ToString();
                            }
                        }
                        MessageBox.Show(kiirasok);
                    }
                }           
            }
            catch (Exception)
            {
                MessageBox.Show("Valami hiba történt!");
            }
        }
        //VLSM
        private void hozzaad_Click(object sender, RoutedEventArgs e)
        {
            RadioButton listaelem = new RadioButton();
            listaelem.Content = "Host " + (lista.Items.Count + 1) + ": " + beviteliMezoJobb.Text;
            listaelem.AddHandler(RadioButton.CheckedEvent, new RoutedEventHandler(listaelem_isChecked));
            hostok.Add(new VLSM((string)listaelem.Content));
            lista.Items.Add(listaelem);
            lista.Items.Refresh();
        }
        private void listaelem_isChecked(object sender, RoutedEventArgs e)
        {
            lista.SelectedItem = sender;
        }
        private void modositas_Click(object sender, RoutedEventArgs e)
        {
            hostok.RemoveAt(lista.SelectedIndex);
            (lista.SelectedItem as RadioButton).Content = "Host " + (lista.SelectedIndex + 1) + ": " + beviteliMezoJobb.Text;
            hostok.Add(new VLSM((string)(lista.SelectedItem as RadioButton).Content));
            lista.Items.Refresh();
        }
        class VLSM
        {
            public string nev;
            public int hostSzam;
            public VLSM(string sor)
            {
                nev = sor.Split(':')[0];
                hostSzam = int.Parse(sor.Split(':')[1]);
            }
        }
        private void szamitJobb_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IP generalasIP = new IP(elsoOktett.Text, masodikOktett.Text, harmadikOktett.Text, negyedikOktett.Text, maszk.Text);
                for (int i = hostok.Count - 1; i > 1; i--)
                {
                    for (int j = 0; j < i; j++)
                    {
                        if (hostok[j].hostSzam < hostok[j + 1].hostSzam)
                        {
                            VLSM seged2 = hostok[j];
                            hostok[j] = hostok[j + 1];
                            hostok[j + 1] = seged2;
                        }
                    }
                }
                if (generalasIP.Maszk <= 0 || generalasIP.Maszk >= 31)
                {
                    MessageBox.Show("Hibás hálózati maszk!");
                    maszk.Text = "";
                }
                else
                {
                    string kiirasok = $"Host neve\t\tHálózati cím\t\tKiosztható címek\t\tSzórási cím\tHálózati maszk\tHálózati maszk decimális formában\n";
                    string[] halozatiCim = generalasIP.Kiiratas.Split('.');
                    for (int i = 0; i < hostok.Count; i++)
                    {
                        int hatvany = 1;
                        int seged = 2;
                        while (Math.Pow(seged, hatvany) <= hostok[i].hostSzam)
                        {
                            hatvany++;
                        }
                        int keszMaszk = (int)generalasIP.Maszk + hatvany;
                        if (keszMaszk < 8 && keszMaszk > 0)
                        {
                            //hálózati
                            kiirasok += $"{hostok[i].nev}\t\t{generalasIP.Kiiratas}\t";
                            //kiosztható
                            generalasIP.ElsoOktett = int.Parse(halozatiCim[0]) + 1;
                            kiirasok += $"{generalasIP.Kiiratas}\t";
                            generalasIP.ElsoOktett = int.Parse(halozatiCim[0]);
                            generalasIP.ElsoOktett = int.Parse(halozatiCim[0]) + Math.Pow(seged, hatvany) - 2;
                            kiirasok += $"{generalasIP.Kiiratas}\t";
                            generalasIP.ElsoOktett = int.Parse(halozatiCim[0]);
                            //szórási
                            generalasIP.ElsoOktett = int.Parse(halozatiCim[0]) + Math.Pow(seged, hatvany) - 1;
                            if (int.Parse(halozatiCim[0]) >= 256)
                            {
                                int maradek = int.Parse(halozatiCim[0]) - 255;
                                halozatiCim[1] = maradek.ToString();
                            }
                            //maszkok
                            kiirasok += $"{generalasIP.Kiiratas}\t/{keszMaszk}\t\t{Decimalis(keszMaszk)}\n";
                            generalasIP.ElsoOktett = int.Parse(halozatiCim[0]) + Math.Pow(seged, hatvany);
                            halozatiCim[0] = generalasIP.ElsoOktett.ToString();
                        }
                        else if (keszMaszk >= 8 && keszMaszk < 16)
                        {
                            //hálózati
                            kiirasok += $"{hostok[i].nev}\t\t{generalasIP.Kiiratas}\t";
                            //kiosztható
                            generalasIP.MasodikOktett = int.Parse(halozatiCim[1]) + 1;
                            kiirasok += $"{generalasIP.Kiiratas}\t";
                            generalasIP.MasodikOktett = int.Parse(halozatiCim[1]);
                            generalasIP.MasodikOktett = int.Parse(halozatiCim[1]) + Math.Pow(seged, hatvany) - 2;
                            kiirasok += $"{generalasIP.Kiiratas}\t";
                            generalasIP.MasodikOktett = int.Parse(halozatiCim[1]);
                            //szórási
                            generalasIP.MasodikOktett = int.Parse(halozatiCim[1]) + Math.Pow(seged, hatvany) - 1;
                            if (int.Parse(halozatiCim[1]) >= 256)
                            {
                                int maradek = int.Parse(halozatiCim[1]) - 255;
                                halozatiCim[2] = maradek.ToString();
                            }
                            //maszkok
                            kiirasok += $"{generalasIP.Kiiratas}\t/{keszMaszk}\t\t{Decimalis(keszMaszk)}\n";
                            generalasIP.MasodikOktett = int.Parse(halozatiCim[1]) + Math.Pow(seged, hatvany);
                            halozatiCim[1] = generalasIP.MasodikOktett.ToString();
                        }
                        else if (keszMaszk >= 16 && keszMaszk < 24)
                        {
                            //hálózati
                            kiirasok += $"{hostok[i].nev}\t\t{generalasIP.Kiiratas}\t";
                            //kiosztható
                            generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]) + 1;
                            kiirasok += $"{generalasIP.Kiiratas}\t";
                            generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]);
                            generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]) + Math.Pow(seged, hatvany) - 2;
                            kiirasok += $"{generalasIP.Kiiratas}\t";
                            generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]);
                            //szórási
                            generalasIP.HarmadikOktett = int.Parse(halozatiCim[2]) + Math.Pow(seged, hatvany) - 1;
                            if (int.Parse(halozatiCim[2]) >= 256)
                            {
                                int maradek = int.Parse(halozatiCim[2]) - 255;
                                halozatiCim[3] = maradek.ToString();
                            }
                            //maszkok
                            kiirasok += $"{generalasIP.Kiiratas}\t/{keszMaszk}\t\t{Decimalis(keszMaszk)}\n";
                            generalasIP.HarmadikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany);
                            halozatiCim[3] = generalasIP.HarmadikOktett.ToString();
                        }
                        else if (keszMaszk >= 24 && keszMaszk < 32)
                        {
                            //hálózati
                            kiirasok += $"{hostok[i].nev}\t\t{generalasIP.Kiiratas}\t";
                            //kiosztható
                            generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + 1;
                            kiirasok += $"{generalasIP.Kiiratas}\t";
                            generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]);
                            generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany) - 2;
                            kiirasok += $"{generalasIP.Kiiratas}\t";
                            generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]);
                            //szórási
                            generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany) - 1;
                            //maszkok
                            kiirasok += $"{generalasIP.Kiiratas}\t/{keszMaszk}\t\t{Decimalis(keszMaszk)}\n";
                            generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany);
                            halozatiCim[3] = generalasIP.NegyedikOktett.ToString();
                        }
                    }
                    MessageBox.Show(kiirasok);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Valami hiba történt!");
            }
        }
    }
}