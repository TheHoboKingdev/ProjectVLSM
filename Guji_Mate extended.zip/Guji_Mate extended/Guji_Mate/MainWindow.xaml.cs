﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Guji_Mate
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AlhaloG.Visibility = Visibility.Hidden;
            Vlsm.Visibility = Visibility.Hidden;
        }
        private void sugoGomb_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Gépelje be a hálózati cím négy oktettjét a megfelelő rublikákba. Szóközt és pontot ne használjon! Az ötödik rublikába írja bele " +
                "az alhálózati maszkot decimális alakban! Szóközt és perjelet ne használjon! \n Az \"Alhálózatokra bontás\" rádiógombra való kattintás után adja meg, hogy " +
                "hány egyenlő részre szeretné bontani a címet. A \"Számít\" gombra való kattintás után a program elvégzi a számítást a megadott feltételeknek megfelelően \n  " +
                "A \"VLSM\" rádiógombra való kattintás után adja meg, melyik hálózatban mennyi hosztot szeretne. Elsőként a legtöbb hosztot igénylő hálózat méretét írja be a beviteli mezőbe, másodjára a második legtöbb hosztot igénylő hálózatét és így tovább." +
                " Amennyiben elírt valamit,vagy szerkeszteni szeretné valamelyik hálózat méretét, a mellete elhelyezett jelőlőnégyzet bepipálásával átírhatja a beviteli mezőben megadot értéket és a \"Módosít\" gombra kattintva már módosításra is kerül az érték. A \"Számít\" gombra való kattintás után a program elvégzi a számítást a megadott feltételeknek megfelelően");
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            AlhaloG.Visibility = Visibility.Visible;
            Vlsm.Visibility = Visibility.Hidden;
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            AlhaloG.Visibility = Visibility.Hidden;
            Vlsm.Visibility = Visibility.Visible;
        }
        class IP
        {
            public double ElsoOktett;
            public double MasodikOktett;
            public double HarmadikOktett;
            public double NegyedikOktett;
            public double
                Maszk;
            public int hostSzam;
            public IP(string ElsoOktett, string MasodikOktett, string HarmadikOktett, string NegyedikOktett, string Maszk, string hostSzam)
            {
                this.ElsoOktett = byte.Parse(ElsoOktett);
                this.MasodikOktett = byte.Parse(MasodikOktett);
                this.HarmadikOktett = byte.Parse(HarmadikOktett);
                this.NegyedikOktett = byte.Parse(NegyedikOktett);
                this.Maszk = byte.Parse(Maszk);
                this.hostSzam = int.Parse(hostSzam);
            }
            public string Kiiratas { get => $"{ElsoOktett}.{MasodikOktett}.{HarmadikOktett}.{NegyedikOktett}"; }
        }
        private string Decimalis(int maszk)
        {
            string decimalisMaszk;
            int[] oktettMaszk = { 0, 0, 0, 0 };
            int maradekMaszk = maszk - maszk % 8;
            if (maszk < 8)
                oktettMaszk[0] = Vizsgalat(maszk);
            else if (maszk == 8)
                oktettMaszk[0] = 255;
            else if (maszk < 16 && maszk > 8)
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = Vizsgalat(maszk % 8);
            }
            else if (maszk == 16)
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = 255;
            }
            else if (maszk < 24 && maszk > 16)
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = 255;
                oktettMaszk[2] = Vizsgalat(maszk % 8);
            }
            else if (maszk == 24)
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = 255;
                oktettMaszk[2] = 255;
            }
            else
            {
                oktettMaszk[0] = 255;
                oktettMaszk[1] = 255;
                oktettMaszk[2] = 255;
                oktettMaszk[3] = Vizsgalat(maszk % 8);
            }
            decimalisMaszk = $"{oktettMaszk[0]}.{oktettMaszk[1]}.{oktettMaszk[2]}.{oktettMaszk[3]}";
            return decimalisMaszk;
        }
        private int Vizsgalat(int vizsgalando)
        {
            switch (vizsgalando)
            {
                case 1:
                    return 128;
                    break;
                case 2:
                    return 192;
                    break;
                case 3:
                    return 224;
                    break;
                case 4:
                    return 240;
                    break;
                case 5:
                    return 248;
                    break;
                case 6:
                    return 252;
                    break;
                default:
                    return 254;
                    break;
            }
        }

        private void szamitBal_Click(object sender, RoutedEventArgs e)
        {
            if (egyenloResz.IsChecked == true)
            {
                IP generalasIP = new IP(elsoOktett.Text, masodikOktett.Text, harmadikOktett.Text, negyedikOktett.Text, maszk.Text, "0");
                int hatvany = 1;
                int seged = 2;
                while (Math.Pow(seged, hatvany) <= int.Parse(beviteliMezoBal.Text))
                {
                    hatvany++;
                }
                int keszMaszk = 32 - hatvany;
                string kiirasok = $"Host neve\tHálózati cím\tKiosztható címek\tSzórási cím\tHálózati maszk\tHálózati maszk decimális formában\n";
                string[] halozatiCim = generalasIP.Kiiratas.Split('.');
                for (int i = 0; i < int.Parse(beviteliMezoBal.Text); i++)
                {
                    //hálóztai
                    kiirasok += $"Host{i + 1}\t{generalasIP.Kiiratas}\t";
                    //kiosztható
                    generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + i + 1;
                    kiirasok += $"{generalasIP.Kiiratas}\t";
                    generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany) - 2;
                    kiirasok += $"{generalasIP.Kiiratas}\t";
                    //szórási
                    generalasIP.NegyedikOktett = int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany) - 1;
                    if (int.Parse(halozatiCim[3]) >= 256)
                    {
                        int maradek = int.Parse(halozatiCim[3]) - 255;
                        halozatiCim[2] = (int.Parse(halozatiCim[2]) + 1).ToString();
                        halozatiCim[3] = maradek.ToString();
                    }
                    //maszkok
                    kiirasok += $"{generalasIP.Kiiratas}\t\\{keszMaszk}\t{Decimalis(keszMaszk)}\n";
                    generalasIP.NegyedikOktett += int.Parse(halozatiCim[3]) + Math.Pow(seged, hatvany) + 1;
                }
                MessageBox.Show(kiirasok);
            }
        }
    }
}
